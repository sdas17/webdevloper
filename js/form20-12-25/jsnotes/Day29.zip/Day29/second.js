console.log("HEllo Coder Army");

setTimeout(()=>{
  const a = 2+4;
  console.log(a);
},5000);

let b = 20;
let arr = [20,30,11];

for(let i of arr)
    console.log(i*b);

