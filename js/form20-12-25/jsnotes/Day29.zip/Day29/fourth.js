console.log("I am first");

fetch("https://youtube.com")
.then(()=>console.log("Hello"));

console.log("I am last");